from django.shortcuts import render, redirect 
from .forms import TextoAnalizadoForm 
from .models import TextoAnalizado 

def subir_texto(request): 
    if request.method == 'POST': 
        form = TextoAnalizadoForm(request.POST, request.FILES) 
        if form.is_valid(): 
            form.save() 
            return redirect('lista_textos') 
    else: 
        form = TextoAnalizadoForm() 
    return render(request, 'analisis/subir.html', {'form': form}) 

def lista_textos(request): 
    textos = TextoAnalizado.objects.all().order_by('-fecha_subida') 
    return render(request, 'analisis/lista.html', {'textos': textos})

# Create your views here.
